extends Control

const MatchSettings = preload("res://source/data-model/MatchSettings.gd")
const PlayerSettings = preload("res://source/data-model/PlayerSettings.gd")
const LoadingScene = preload("res://source/main-menu/Loading.tscn")

# جديد: تحميل الفصائل
const Faction1 = preload("res://factions/faction_default.tres")
const Faction2 = preload("res://factions/faction_default2.tres")

var _map_paths = []

@onready var _start_button = find_child("StartButton")
@onready var _map_list = find_child("MapList")
@onready var _map_details = find_child("MapDetailsLabel")
@onready var _initial_resources_selector = find_child("InitialResourcesSelector")

func _ready():
	_setup_map_list()
	_on_map_list_item_selected(0)

	var option_nodes = find_child("GridContainer").find_children("OptionButton*")
	var faction_nodes = find_child("GridContainer").find_children("FactionButton*")
	var team_nodes = find_child("GridContainer").find_children("TeamButton*")

	for option_node_id in range(option_nodes.size()):
		option_nodes[option_node_id].item_selected.connect(_on_player_selected.bind(option_node_id))
		faction_nodes[option_node_id].item_selected.connect(_on_faction_selected.bind(option_node_id))
		team_nodes[option_node_id].item_selected.connect(_on_team_selected.bind(option_node_id))

		# جديد: إذا اللاعب افتراضيًا None → قفل زر الفصيل والتيم
		if option_nodes[option_node_id].selected == Constants.PlayerType.NONE:
			faction_nodes[option_node_id].disabled = true
			faction_nodes[option_node_id].selected = 0
			team_nodes[option_node_id].disabled = true
			team_nodes[option_node_id].selected = 0
		else:
			faction_nodes[option_node_id].disabled = false
			team_nodes[option_node_id].disabled = false

func _setup_map_list():
	var maps = Utils.Dict.items(Constants.Match.MAPS)
	maps.sort_custom(func(map_a, map_b): return map_a[1]["players"] < map_b[1]["players"])
	_map_paths = maps.map(func(map): return map[0])
	_map_list.clear()
	for map_path in _map_paths:
		_map_list.add_item(Constants.Match.MAPS[map_path]["name"])
	_map_list.select(0)

func _create_match_settings():
	var match_settings = MatchSettings.new()

	var option_nodes = find_child("GridContainer").find_children("OptionButton*")
	var faction_nodes = find_child("GridContainer").find_children("FactionButton*")
	var team_nodes = find_child("GridContainer").find_children("TeamButton*")

	# قراءة الموارد الأولية من القائمة
	var selected_text = _initial_resources_selector.get_item_text(_initial_resources_selector.selected)
	var parts = selected_text.split("/")
	var initial_red = int(parts[0])
	var initial_blue = int(parts[1])
	match_settings.initial_resources = {"resource_a": initial_red, "resource_b": initial_blue}

	var spawn_index_offset = 0
	for option_node_id in range(option_nodes.size()):
		var player_controller = option_nodes[option_node_id].selected
		if player_controller != Constants.PlayerType.NONE:
			var player_settings = PlayerSettings.new()
			player_settings.controller = player_controller
			player_settings.color = Constants.PlayerConstants.COLORS[option_node_id]
			player_settings.spawn_index_offset = spawn_index_offset

			# اختيار الفصيل
			var faction_choice = faction_nodes[option_node_id].selected
			if faction_choice == 0:
				# عشوائي: اختار بين فصيل 1 وفصيل 2
				var random_pick = randi() % 2
				if random_pick == 0:
					player_settings.faction = Faction1
				else:
					player_settings.faction = Faction2
			elif faction_choice == 1:
				player_settings.faction = Faction1
			else:
				player_settings.faction = Faction2

			# اختيار الفريق
			player_settings.team = team_nodes[option_node_id].selected

			match_settings.players.append(player_settings)
			spawn_index_offset = 0
		else:
			spawn_index_offset += 1

	match_settings.visible_player = -1
	for player_id in range(match_settings.players.size()):
		var player = match_settings.players[player_id]
		if player.controller == Constants.PlayerType.HUMAN:
			match_settings.visible_player = player_id
	if match_settings.visible_player == -1:
		match_settings.visibility = match_settings.Visibility.ALL_PLAYERS

	return match_settings

func _get_selected_map_path():
	return _map_paths[_map_list.get_selected_items()[0]]

func _on_start_button_pressed():
	hide()
	var new_scene = LoadingScene.instantiate()
	new_scene.match_settings = _create_match_settings()
	new_scene.map_path = _get_selected_map_path()
	get_parent().add_child(new_scene)
	get_tree().current_scene = new_scene
	queue_free()

func _on_back_button_pressed():
	get_tree().change_scene_to_file("res://source/main-menu/Main.tscn")

func _align_player_controls_visibility_to_map(map):
	var option_nodes = find_child("GridContainer").find_children("OptionButton*")
	var label_nodes = find_child("GridContainer").find_children("Label*")
	var faction_nodes = find_child("GridContainer").find_children("FactionButton*")
	var team_nodes = find_child("GridContainer").find_children("TeamButton*")
	assert(option_nodes.size() == label_nodes.size())
	for node_id in range(option_nodes.size()):
		var visible = node_id < map["players"]
		option_nodes[node_id].visible = visible
		label_nodes[node_id].visible = visible
		faction_nodes[node_id].visible = visible
		team_nodes[node_id].visible = visible

func _on_player_selected(selected_option_id, selected_player_id):
	_start_button.disabled = false
	var option_nodes = find_child("GridContainer").find_children("OptionButton*")
	var faction_nodes = find_child("GridContainer").find_children("FactionButton*")
	var team_nodes = find_child("GridContainer").find_children("TeamButton*")

	if selected_option_id == Constants.PlayerType.HUMAN:
		for option_node_id in range(option_nodes.size()):
			if (
				option_node_id != selected_player_id
				and option_nodes[option_node_id].selected == Constants.PlayerType.HUMAN
			):
				option_nodes[option_node_id].selected = Constants.PlayerType.SIMPLE_CLAIRVOYANT_AI
		faction_nodes[selected_player_id].disabled = false
		team_nodes[selected_player_id].disabled = false

	elif selected_option_id == Constants.PlayerType.SIMPLE_CLAIRVOYANT_AI:
		faction_nodes[selected_player_id].disabled = false
		team_nodes[selected_player_id].disabled = false

	elif selected_option_id == Constants.PlayerType.NONE:
		faction_nodes[selected_player_id].disabled = true
		faction_nodes[selected_player_id].selected = 0
		team_nodes[selected_player_id].disabled = true
		team_nodes[selected_player_id].selected = 0

		var option_nodes_with_player_controllers = (
			option_nodes.filter(func(option_node): return option_node.selected != Constants.PlayerType.NONE)
		)
		if option_nodes_with_player_controllers.size() < 2:
			_start_button.disabled = true

# جديد: حدث اختيار الفصيل
func _on_faction_selected(selected_option_id, player_id):
	pass # حالياً ما نحتاج نعمل شيء إضافي، القيمة تُقرأ في _create_match_settings

# جديد: حدث اختيار الفريق
func _on_team_selected(selected_option_id, player_id):
	pass # حالياً ما نحتاج نعمل شيء إضافي، القيمة تُقرأ في _create_match_settings

func _on_map_list_item_selected(index):
	var map = Constants.Match.MAPS[_map_paths[index]]
	_map_details.text = "[u]Players:[/u] {0}\n[u]Size:[/u] {1}x{2}".format(
		[map["players"], map["size"].x, map["size"].y]
	)
	_align_player_controls_visibility_to_map(map)
