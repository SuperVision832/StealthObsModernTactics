extends Control

const hold_sound = preload("res://assets/sounds/button_hold.mp3")

@onready var _rich_text_label = find_child("RichTextLabel")


func _ready():
	_rich_text_label.text = (
		_rich_text_label
		. text
		. replace("CORE_CONTRIBUTORS", tr("CORE_CONTRIBUTORS"))
		. replace("ASSETS", tr("ASSETS"))
	)


func _on_back_button_pressed():
	get_tree().change_scene_to_file("res://source/main-menu/Main.tscn")


func _on_button_mouse_entered() -> void:
	if hold_sound:
		var audio_player = AudioStreamPlayer.new()
		audio_player.stream = hold_sound
		add_child(audio_player)
		audio_player.play()
		audio_player.connect("finished", audio_player.queue_free) 
