extends Control

const hold_sound = preload("res://assets/sounds/button_hold.mp3")
const click_sound = preload("res://assets/sounds/button_click.mp3")


func _on_play_button_pressed():
	get_tree().change_scene_to_file("res://source/main-menu/Play.tscn")


func _on_options_button_pressed():
	get_tree().change_scene_to_file("res://source/main-menu/Options.tscn")

func _on_credits_button_pressed():
	get_tree().change_scene_to_file("res://source/main-menu/Credits.tscn")

func _on_quit_button_pressed():
	get_tree().quit()

func _on_button_mouse_entered() -> void:
	if hold_sound:
		var audio_player = AudioStreamPlayer.new()
		audio_player.stream = hold_sound
		add_child(audio_player)
		audio_player.play()
		audio_player.connect("finished", audio_player.queue_free)


func _on_button_pressed() -> void:
	if click_sound:
		var audio_player = AudioStreamPlayer.new()
		audio_player.stream = click_sound
		add_child(audio_player)
		audio_player.play()
		audio_player.connect("finished", audio_player.queue_free)
