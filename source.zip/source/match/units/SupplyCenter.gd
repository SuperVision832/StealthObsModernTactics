extends "res://source/match/units/Structure.gd"

# مركز الإمداد مسؤول عن استقبال الموارد من الشاحنات وتحويلها لرصيد اللاعب

func deposit_resources(a: int, b: int) -> void:
	if player != null:
		player.add_resources(a, b)
