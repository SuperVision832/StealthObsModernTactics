extends Node

enum State { FORMING, ATTACKING }

const PLAYER_TO_ATTACK_SWITCHING_DELAY_S = 0.5

class Actions:
	const MovingToUnit = preload("res://source/match/units/actions/MovingToUnit.gd")
	const AutoAttacking = preload("res://source/match/units/actions/AutoAttacking.gd")

var _expected_number_of_units: int = 0
var _players_to_attack: Array = []
var _player_to_attack: Player = null

var _state: State = State.FORMING
var _attached_units: Array = []


func _init(expected_number_of_units: int, players_to_attack: Array):
	_expected_number_of_units = expected_number_of_units
	_players_to_attack = players_to_attack.duplicate()
	_players_to_attack = _players_to_attack.filter(func(p): return p != null)
	if not _players_to_attack.is_empty():
		_player_to_attack = _players_to_attack.front()


func size() -> int:
	return _attached_units.size()


func can_accept_more_units() -> bool:
	return size() < _expected_number_of_units and _state == State.FORMING


func attach_unit(unit):
	if _state != State.FORMING or unit == null:
		return
	_attached_units.append(unit)
	unit.tree_exited.connect(_on_unit_died.bind(unit))
	if size() == _expected_number_of_units:
		_start_attacking()


func _start_attacking():
	if _attached_units.is_empty():
		queue_free()
		return
	_state = State.ATTACKING
	_attack_next_adversary_unit()


func _attack_next_adversary_unit():
	if _player_to_attack == null or _attached_units.is_empty():
		return

	var my_team = _attached_units[0].player.team if _attached_units[0].player != null else -1

	# فلترة بحيث يتجاهل وحدات من نفس الفريق ويهاجم فقط الأعداء
	var adversary_units = get_tree().get_nodes_in_group("units").filter(
		func(unit):
			return unit.player != null \
				and unit.player == _player_to_attack \
				and unit.player.team != my_team
	)

	if adversary_units.is_empty():
		_attack_next_player()
		return

	var battlegroup_position = _attached_units[0].global_position
	var adversary_units_sorted_by_distance = adversary_units.map(
		func(adversary_unit): return {
			"distance":
			(adversary_unit.global_position * Vector3(1, 0, 1)).distance_to(
				battlegroup_position * Vector3(1, 0, 1)
			),
			"unit": adversary_unit
		}
	)
	adversary_units_sorted_by_distance.sort_custom(
		func(tuple_a, tuple_b): return tuple_a["distance"] < tuple_b["distance"]
	)

	for tuple in adversary_units_sorted_by_distance:
		var target_unit = tuple["unit"]
		if _attached_units.any(
			func(attached_unit): return Actions.AutoAttacking.is_applicable(attached_unit, target_unit)
		):
			target_unit.tree_exited.connect(_on_target_unit_died, CONNECT_DEFERRED)
			for attached_unit in _attached_units:
				if Actions.AutoAttacking.is_applicable(attached_unit, target_unit):
					attached_unit.action = Actions.AutoAttacking.new(target_unit)
				else:
					attached_unit.action = Actions.MovingToUnit.new(target_unit)
			return

	# إذا ما في وحدات ممكن مهاجمتها
	_attack_next_player()


func _attack_next_player():
	if _players_to_attack.is_empty():
		return
	var player_to_attack_index = _players_to_attack.find(_player_to_attack)
	var next_player_to_attack_index = (player_to_attack_index + 1) % _players_to_attack.size()
	_player_to_attack = _players_to_attack[next_player_to_attack_index]
	get_tree().create_timer(PLAYER_TO_ATTACK_SWITCHING_DELAY_S).timeout.connect(
		_attack_next_adversary_unit
	)


func _on_unit_died(unit):
	if not is_inside_tree():
		return
	_attached_units.erase(unit)
	if _state == State.ATTACKING and _attached_units.is_empty():
		queue_free()


func _on_target_unit_died():
	if not is_inside_tree():
		return
	_attack_next_adversary_unit()
