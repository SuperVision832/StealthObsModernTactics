extends NavigationAgent3D

signal movement_finished
signal passive_movement_started
signal passive_movement_finished

const INITIAL_DISPERSION_FACTOR = 0.1

@export var domain = Constants.Match.Navigation.Domain.TERRAIN

var speed: float = 4.0
var unit_type: String = "ground"

var _interim_speed: float = 0.0
var _previously_set_global_transform_of_unit = null
@warning_ignore("unused_private_class_variable")
var _passive_movement_detected = false

@onready var _match = find_parent("Match")
@onready var _unit = get_parent()


func _ready():
	if _match.navigation == null:
		await _match.ready

	# قراءة الخصائص من Constants.Match
	var props: Dictionary = Constants.Match.Units.DEFAULT_PROPERTIES.get(_unit.scene_file_path, {})
	speed = float(props.get("speed", speed))
	unit_type = String(props.get("unit_type", unit_type))

	# ضبط الدومين حسب النوع
	match unit_type:
		"helicopter", "jet":
			domain = Constants.Match.Navigation.Domain.AIR
		_:
			domain = Constants.Match.Navigation.Domain.TERRAIN

	velocity_computed.connect(_on_velocity_computed)
	navigation_finished.connect(_on_navigation_finished)
	set_navigation_map(_match.navigation.get_navigation_map_rid_by_domain(domain))
	_align_unit_position_to_navigation()

	# تشتت بسيط لتخفيف التزاحم عند البداية
	move(_unit.global_position + Vector3(randf(), 0, randf()).normalized() * INITIAL_DISPERSION_FACTOR)


func _physics_process(delta: float) -> void:
	_interim_speed = speed * delta
	match unit_type:
		"ground":
			_move_on_terrain(delta)
		"helicopter":
			_hover_above_ground(delta)
		"jet":
			_fly_with_tilt(delta)


# --- الوحدات الأرضية ---
func _move_on_terrain(_delta: float) -> void:
	var next_path_position: Vector3 = get_next_path_position()
	var current_agent_position: Vector3 = _unit.global_transform.origin
	var direction: Vector3 = (next_path_position - current_agent_position).normalized()
	var new_velocity: Vector3 = direction * _interim_speed
	set_velocity(new_velocity)

	# دوران الجسم لجهة الحركة
	if not direction.is_zero_approx():
		_unit.look_at(_unit.global_transform.origin + direction, Vector3.UP)

	_align_to_terrain()


# --- الهليكوبتر (يميل عند الحركة، مستقيم عند الوقوف) ---
func _hover_above_ground(_delta: float) -> void:
	var ground_height: float = get_ground_height(_unit.global_transform.origin)
	_unit.global_transform.origin.y = ground_height + 5.0

	var next_path_position: Vector3 = get_next_path_position()
	var current_agent_position: Vector3 = _unit.global_transform.origin
	var direction: Vector3 = (next_path_position - current_agent_position).normalized()

	if not direction.is_zero_approx():
		# دوران الجسم لجهة الحركة
		_unit.look_at(_unit.global_transform.origin + direction, Vector3.UP)

		# ميلان إضافي
		var tilt_strength: float = 0.2
		var basis: Basis = _unit.global_transform.basis
		basis = basis.rotated(Vector3.RIGHT, -direction.z * tilt_strength)
		basis = basis.rotated(Vector3.FORWARD, direction.x * tilt_strength)
		_unit.global_transform.basis = basis

		set_velocity(direction * _interim_speed)
	else:
		_unit.global_transform.basis = Basis()
		set_velocity(Vector3.ZERO)


# --- الطائرات النفاثة ---
func _fly_with_tilt(_delta: float) -> void:
	var next_path_position: Vector3 = get_next_path_position()
	var current_agent_position: Vector3 = _unit.global_transform.origin
	var direction: Vector3 = (next_path_position - current_agent_position).normalized()
	var new_velocity: Vector3 = direction * _interim_speed
	set_velocity(new_velocity)

	if not direction.is_zero_approx():
		_unit.look_at(_unit.global_transform.origin + direction, Vector3.UP)

	var ground_height: float = get_ground_height(_unit.global_transform.origin)
	_unit.global_transform.origin.y = ground_height + 10.0
	_align_to_terrain()


# --- دالة قراءة ارتفاع التضاريس ---
func get_ground_height(position: Vector3) -> float:
	var space_state: PhysicsDirectSpaceState3D = get_viewport().get_world_3d().direct_space_state
	var from: Vector3 = position + Vector3.UP * 50.0
	var to: Vector3 = position + Vector3.DOWN * 100.0
	var query: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(from, to)
	query.collision_mask = 1
	var result: Dictionary = space_state.intersect_ray(query)
	if result:
		return float(result.position.y)
	return 0.0


# --- دالة الميلان مع التضاريس ---
func _align_to_terrain() -> void:
	var space_state: PhysicsDirectSpaceState3D = get_viewport().get_world_3d().direct_space_state
	var from: Vector3 = _unit.global_transform.origin + Vector3.UP * 10.0
	var to: Vector3 = _unit.global_transform.origin + Vector3.DOWN * 20.0
	var query: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(from, to)
	query.collision_mask = 1
	var result: Dictionary = space_state.intersect_ray(query)
	if result:
		var normal: Vector3 = (result.normal as Vector3).normalized()
		var basis: Basis = Basis()
		basis.y = normal
		basis.x = basis.y.cross(Vector3.FORWARD).normalized()
		basis.z = basis.x.cross(basis.y).normalized()
		_unit.global_transform.basis = basis


# --- التحكم القياسي بالحركة ---
func move(movement_target: Vector3) -> void:
	target_position = movement_target

func stop() -> void:
	target_position = Vector3.INF

func _align_unit_position_to_navigation() -> void:
	await get_tree().process_frame
	_unit.global_transform.origin = (
		NavigationServer3D.map_get_closest_point(get_navigation_map(), get_parent().global_transform.origin)
		- Vector3(0, path_height_offset, 0)
	)

func _is_moving_actively() -> bool:
	return get_next_path_position() != _unit.global_position

func _on_velocity_computed(safe_velocity: Vector3) -> void:
	_unit.global_transform.origin = _unit.global_transform.origin.move_toward(
		_unit.global_transform.origin + safe_velocity, _interim_speed
	)
	_previously_set_global_transform_of_unit = _unit.global_transform

func _on_navigation_finished() -> void:
	target_position = Vector3.INF
	movement_finished.emit()
