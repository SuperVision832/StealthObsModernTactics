extends Node

signal resources_required(resources, metadata)

const CommandCenter = preload("res://source/match/units/CommandCenter.gd")
const CommandCenterScene = preload("res://source/match/units/CommandCenter.tscn")
const SupplyCenter = preload("res://source/match/units/SupplyCenter.gd")
const SupplyCenterScene = preload("res://source/match/units/SupplyCenter.tscn")
const SupplyTruck = preload("res://source/match/units/SupplyTruck.gd")
const SupplyTruckScene = preload("res://source/match/units/SupplyTruck.tscn")

var _player: Player = null
var _supply_centers: Array = []
var _supply_trucks: Array = []
var _ccs: Array = []
var _number_of_pending_cc_resource_requests: int = 0
var _number_of_pending_supply_center_requests: int = 0
var _number_of_pending_truck_requests: int = 0
var _cc_base_position: Vector3 = Vector3.ZERO

@onready var _ai = get_parent()


func setup(player: Player):
	_player = player
	_attach_current_ccs()
	_attach_current_supply_centers()
	_attach_current_trucks()
	MatchSignals.unit_spawned.connect(_on_unit_spawned)
	_enforce_number_of_ccs()
	_enforce_number_of_supply_centers()
	_enforce_number_of_trucks()


func provision(resources: Dictionary, metadata: String):
	if metadata == "supply_center":
		assert(resources == Constants.Match.Units.CONSTRUCTION_COSTS[SupplyCenterScene.resource_path])
		_number_of_pending_supply_center_requests -= 1
		_construct_supply_center()
	elif metadata == "supply_truck":
		assert(resources == Constants.Match.Units.PRODUCTION_COSTS[SupplyTruckScene.resource_path])
		_number_of_pending_truck_requests -= 1
		if _supply_centers.is_empty():
			return
		var center = _supply_centers[0]
		if center.is_constructed():
			center.production_queue.produce(SupplyTruckScene, true)
	elif metadata == "cc":
		assert(resources == Constants.Match.Units.CONSTRUCTION_COSTS[CommandCenterScene.resource_path])
		_number_of_pending_cc_resource_requests -= 1
		_construct_cc()
	else:
		assert(false, "unexpected flow")


func _attach_cc(cc: CommandCenter):
	if cc in _ccs:
		return
	_ccs.append(cc)
	cc.tree_exited.connect(_on_cc_died.bind(cc))


func _attach_current_ccs():
	var ccs = get_tree().get_nodes_in_group("units").filter(
		func(unit): return unit.player == _player and unit.scene_file_path == CommandCenterScene.resource_path
	)
	if not ccs.is_empty():
		_cc_base_position = ccs[0].global_position
	for cc in ccs:
		_attach_cc(cc)


func _attach_supply_center(center: SupplyCenter):
	if center in _supply_centers:
		return
	_supply_centers.append(center)
	center.tree_exited.connect(_on_supply_center_died.bind(center))


func _attach_current_supply_centers():
	var centers = get_tree().get_nodes_in_group("units").filter(
		func(unit): return unit is SupplyCenter and unit.player == _player
	)
	for center in centers:
		_attach_supply_center(center)


func _attach_truck(truck: SupplyTruck):
	if truck in _supply_trucks:
		return
	_supply_trucks.append(truck)
	truck.tree_exited.connect(_on_truck_died.bind(truck))


func _attach_current_trucks():
	var trucks = get_tree().get_nodes_in_group("units").filter(
		func(unit): return unit is SupplyTruck and unit.player == _player
	)
	for truck in trucks:
		_attach_truck(truck)


func _enforce_number_of_ccs():
	if _ccs.size() + _number_of_pending_cc_resource_requests >= _ai.expected_number_of_ccs:
		return
	var extra = _ai.expected_number_of_ccs - (_ccs.size() + _number_of_pending_cc_resource_requests)
	for i in range(extra):
		resources_required.emit(Constants.Match.Units.CONSTRUCTION_COSTS[CommandCenterScene.resource_path], "cc")
		_number_of_pending_cc_resource_requests += 1


func _enforce_number_of_supply_centers():
	if _supply_centers.size() + _number_of_pending_supply_center_requests >= _ai.expected_number_of_supply_centers:
		return
	var extra = _ai.expected_number_of_supply_centers - (_supply_centers.size() + _number_of_pending_supply_center_requests)
	for i in range(extra):
		resources_required.emit(Constants.Match.Units.CONSTRUCTION_COSTS[SupplyCenterScene.resource_path], "supply_center")
		_number_of_pending_supply_center_requests += 1


func _enforce_number_of_trucks():
	if _supply_trucks.size() + _number_of_pending_truck_requests >= _ai.expected_number_of_trucks:
		return
	var extra = _ai.expected_number_of_trucks - (_supply_trucks.size() + _number_of_pending_truck_requests)
	for i in range(extra):
		resources_required.emit(Constants.Match.Units.PRODUCTION_COSTS[SupplyTruckScene.resource_path], "supply_truck")
		_number_of_pending_truck_requests += 1


func _construct_cc():
	var cost = Constants.Match.Units.CONSTRUCTION_COSTS[CommandCenterScene.resource_path]
	assert(_player.has_resources(cost))
	var unit_to_spawn = CommandCenterScene.instantiate()
	var placement_position = Utils.Match.Unit.Placement.find_valid_position_radially(
		_cc_base_position,
		unit_to_spawn.radius + Constants.Match.Units.EMPTY_SPACE_RADIUS_SURROUNDING_STRUCTURE_M,
		find_parent("Match").navigation.get_navigation_map_rid_by_domain(unit_to_spawn.movement_domain),
		get_tree()
	)
	var target_transform = Transform3D(Basis(), placement_position)
	_player.subtract_resources(cost)
	MatchSignals.setup_and_spawn_unit.emit(unit_to_spawn, target_transform, _player)


func _construct_supply_center():
	var cost = Constants.Match.Units.CONSTRUCTION_COSTS[SupplyCenterScene.resource_path]
	assert(_player.has_resources(cost))
	var unit_to_spawn = SupplyCenterScene.instantiate()
	var placement_position = Utils.Match.Unit.Placement.find_valid_position_radially(
		_cc_base_position,
		unit_to_spawn.radius + Constants.Match.Units.EMPTY_SPACE_RADIUS_SURROUNDING_STRUCTURE_M,
		find_parent("Match").navigation.get_navigation_map_rid_by_domain(unit_to_spawn.movement_domain),
		get_tree()
	)
	var target_transform = Transform3D(Basis(), placement_position)
	_player.subtract_resources(cost)
	MatchSignals.setup_and_spawn_unit.emit(unit_to_spawn, target_transform, _player)


func _on_cc_died(cc: CommandCenter):
	if not is_inside_tree():
		return
	_ccs.erase(cc)
	_enforce_number_of_ccs()


func _on_supply_center_died(center: SupplyCenter):
	if not is_inside_tree():
		return
	_supply_centers.erase(center)
	_enforce_number_of_supply_centers()


func _on_truck_died(truck: SupplyTruck):
	if not is_inside_tree():
		return
	_supply_trucks.erase(truck)
	_enforce_number_of_trucks()


func _on_unit_spawned(unit):
	if unit.player != _player:
		return
	if unit is SupplyTruck:
		_attach_truck(unit)
	elif unit is SupplyCenter:
		_attach_supply_center(unit)
	elif unit.scene_file_path == CommandCenterScene.resource_path:
		_attach_cc(unit)
