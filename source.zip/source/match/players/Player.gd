
extends Node3D
class_name Player
signal changed

@export var resource_a: int = 0:
	set(value):
		resource_a = value
		emit_changed()

@export var resource_b: int = 0:
	set(value):
		resource_b = value
		emit_changed()

@export var color: Color = Color.WHITE

# جديد: خاصية الفريق
@export var team: int = 0

var _color_material = null
var settings


# إضافة موارد لرصيد اللاعب
func add_resources(a: int, b: int) -> void:
	resource_a += a
	resource_b += b
	emit_changed()


# إضافة موارد من Dictionary (للتوافق مع النظام الحالي)
func add_resources_dict(resources: Dictionary) -> void:
	for resource in resources:
		set(resource, get(resource) + resources[resource])
	emit_changed()


func has_resources(resources: Dictionary) -> bool:
	if FeatureFlags.allow_resources_deficit_spending:
		return true
	for resource in resources:
		if get(resource) < resources[resource]:
			return false
	return true


func subtract_resources(resources: Dictionary) -> void:
	for resource in resources:
		set(resource, get(resource) - resources[resource])
	emit_changed()


func get_color_material():
	if _color_material == null:
		_color_material = StandardMaterial3D.new()
		_color_material.vertex_color_use_as_albedo = true
		_color_material.albedo_color = color
		_color_material.metallic = 1
	return _color_material


func emit_changed():
	changed.emit()


# جديد: تعيين الموارد الأولية عند بداية اللعبة
func set_initial_resources(resources: Dictionary):
	if resources.has("resource_a"):
		resource_a = resources["resource_a"]
	if resources.has("resource_b"):
		resource_b = resources["resource_b"]
	emit_changed()


# جديد: نسخ الإعدادات من PlayerSettings
func apply_settings(player_settings):
	settings = player_settings
	color = player_settings.color
	team = player_settings.team
