extends Node3D

const DynamicCircle2D = preload("res://source/generic-scenes-and-nodes/2d/DynamicCircle2D.tscn")
const Human = preload("res://source/match/players/human/Human.gd")

const DEFAULT_SIZE = Vector2i(100, 100)

@export_range(1, 10) var texture_units_per_world_unit = 2  # px/m
@export var fog_circle_color = Color(0.25, 0.25, 0.25)
@export var shroud_circle_color = Color(1.0, 1.0, 1.0)

# خريطة: الفريق → (الوحدة → [shroud_circle, fow_circle])
var _team_to_circles_mapping = {}

@onready var _revealer = find_child("Revealer")
@onready var _fog_viewport = find_child("FogViewport")
@onready var _fog_viewport_container = find_child("FogViewportContainer")
@onready var _combined_viewport = find_child("CombinedViewport")
@onready var _screen_overlay = find_child("ScreenOverlay")


func _ready():
	if _fog_viewport.size == DEFAULT_SIZE:
		resize(find_parent("Match").find_child("Map").size)
	_screen_overlay.material_override.set_shader_parameter(
		"texture_units_per_world_unit", texture_units_per_world_unit
	)
	_revealer.hide()
	find_child("EditorOnlyCircle").queue_free()


func _physics_process(_delta):
	# إذا ما في لاعب بشري → وضع المراقبة
	var human_players = get_tree().get_nodes_in_group("players").filter(func(p): return p is Human)
	if human_players.is_empty():
		# Spectator mode: لا ترسم دوائر، الخريطة مكشوفة بالكامل
		return

	var teams_seen := {}
	var units_to_sync := get_tree().get_nodes_in_group("revealed_units")

	for unit in units_to_sync:
		if not unit.has_method("is_revealing"):
			continue
		if not unit.is_revealing():
			continue

		var sight_range = unit.get("sight_range")
		if sight_range == null:
			continue

		var team_id = unit.player.team if unit.player != null else unit.get_instance_id()
		var unit_id = unit.get_instance_id()

		if not teams_seen.has(team_id):
			teams_seen[team_id] = {}

		if not _team_to_circles_mapping.has(team_id):
			_team_to_circles_mapping[team_id] = {}

		# أنشئ دوائر لهذه الوحدة إذا غير موجودة
		if not _team_to_circles_mapping[team_id].has(unit_id):
			var shroud_circle = DynamicCircle2D.instantiate()
			shroud_circle.color = fog_circle_color
			shroud_circle.radius = sight_range * texture_units_per_world_unit
			_fog_viewport.add_child(shroud_circle)

			var fow_circle = DynamicCircle2D.instantiate()
			fow_circle.color = shroud_circle_color
			fow_circle.radius = sight_range * texture_units_per_world_unit
			_fog_viewport_container.add_sibling(fow_circle)

			_team_to_circles_mapping[team_id][unit_id] = [shroud_circle, fow_circle]
		else:
			# حدّث نصف القطر لو تغيّر sight_range
			var sh = _team_to_circles_mapping[team_id][unit_id][0]
			var fw = _team_to_circles_mapping[team_id][unit_id][1]
			var target_radius = sight_range * texture_units_per_world_unit
			if sh.radius != target_radius:
				sh.radius = target_radius
				fw.radius = target_radius

		# مزامنة موقع الدوائر لهذه الوحدة
		var unit_pos_3d = unit.global_transform.origin
		var unit_pos_2d = Vector2(unit_pos_3d.x, unit_pos_3d.z) * texture_units_per_world_unit
		_team_to_circles_mapping[team_id][unit_id][0].position = unit_pos_2d
		_team_to_circles_mapping[team_id][unit_id][1].position = unit_pos_2d

		teams_seen[team_id][unit_id] = true

	# تنظيف الوحدات غير النشطة
	for team_id in _team_to_circles_mapping.keys():
		var team_units_map = _team_to_circles_mapping[team_id]
		var seen_units = teams_seen[team_id] if teams_seen.has(team_id) else {}
		for unit_id in team_units_map.keys():
			if not seen_units.has(unit_id):
				team_units_map[unit_id][0].queue_free()
				team_units_map[unit_id][1].queue_free()
				team_units_map.erase(unit_id)

	# تنظيف الفرق الفارغة
	for team_id in _team_to_circles_mapping.keys():
		if _team_to_circles_mapping[team_id].is_empty():
			_team_to_circles_mapping.erase(team_id)


func reveal():
	_revealer.show()


func resize(map_size: Vector2):
	_fog_viewport.size = map_size * texture_units_per_world_unit
	_combined_viewport.size = map_size * texture_units_per_world_unit


func _cleanup_all():
	for team_id in _team_to_circles_mapping.keys():
		for unit_id in _team_to_circles_mapping[team_id].keys():
			_team_to_circles_mapping[team_id][unit_id][0].queue_free()
			_team_to_circles_mapping[team_id][unit_id][1].queue_free()
	_team_to_circles_mapping.clear()
