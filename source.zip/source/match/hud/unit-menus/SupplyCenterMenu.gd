extends GridContainer

const SupplyTruckUnit = preload("res://source/match/units/SupplyTruck.tscn")

var unit = null

@onready var _supply_truck_button = find_child("ProduceSupplyTruckButton")


func _ready():
	var supply_truck_properties = Constants.Match.Units.DEFAULT_PROPERTIES[SupplyTruckUnit.resource_path]
	_supply_truck_button.tooltip_text = ("{0} - {1}\n{2} HP, {3} DPS\n{4}: {5}, {6}: {7}".format(
		[
			tr("SUPPLYTRUCK"),
			tr("SUPPLYTRUCK_DESCRIPTION"),
			Constants.Match.Units.DEFAULT_PROPERTIES[SupplyTruckUnit.resource_path]["hp_max"],
			tr("RESOURCE_A"),
			Constants.Match.Units.PRODUCTION_COSTS[SupplyTruckUnit.resource_path]["resource_a"],
			tr("RESOURCE_B"),
			Constants.Match.Units.PRODUCTION_COSTS[SupplyTruckUnit.resource_path]["resource_b"]
		]
	))


func _on_produce_supply_truck_button_pressed():
	unit.production_queue.produce(SupplyTruckUnit)
